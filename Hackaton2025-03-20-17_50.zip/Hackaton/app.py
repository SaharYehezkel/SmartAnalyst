from flask import Flask, request, jsonify, render_template
import google.generativeai as generativeai
import os
import time
from dotenv import load_dotenv
import base64
import pandas as pd
from bs4 import BeautifulSoup
import requests
import csv
import json
import re

# Load API Key
load_dotenv()
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")

# Configure Gemini API
generativeai.configure(api_key=GEMINI_API_KEY)
gemini_model = generativeai.GenerativeModel("gemini-1.5-flash")

# Read the local video file
with open("data\\videos\\test.mp4", "rb") as video_file:
    video_data = base64.b64encode(video_file.read()).decode("utf-8")

# System instruction for the chatbot
SYSTEM_INSTRUCTION = """
You are an aviation analyst. When summarizing a video, extract flight information:
- Flight company (top left corner)
- Flight number
- Registration
- Aircraft type
- Time
- Source and destination airport
Summarize in this format: **Flight {flight_number} of {company} from {source} to {destination} at {time}.**
Long blue lines indicate flight paths. List all countries crossed for each flight path.
For **suspicious activity**, check for **military zones, military aircraft, and air force identification.**
"""


app = Flask(__name__, template_folder="templates", static_folder="static")

# --- DBAgent: reads CSV and answers a query ---
class DBAgent:
    def __init__(self, csv_file: str):
        self.csv_file = csv_file
        self.df = pd.read_csv(csv_file)
    
    def process(self, query: str) -> str:
        """
        For demonstration, create a summary of the CSV and pass it along with the query to Gemini.
        """
        csv_summary = self.df.head(3).to_csv(index=False)
        combined_prompt = (
            f"CSV Data:\n{csv_summary}\n"
            f"Query: {query}\n"
            "Based on the CSV data, provide a concise summary answering the query."
        )
        result = gemini_model.generate_content(combined_prompt)
        return result

# --- VideoAgent with a tool to read video data ---
class VideoAgent:
    def read_video_data(self, video_path: str) -> str:
        """
        Tool:
            Reads the video file from the given path and returns Base64-encoded content.        
        Args:
            video_path: str: Path to the video file.
    
        """
        try:
            # Read the local video file
            with open(video_path, "rb") as video_file:
                video_data = base64.b64encode(video_file.read()).decode("utf-8")
                return video_data
        except Exception as e:
            return f"Error reading video file: {e}"
    
    def process(self, prompt: str) -> str:
        """
        TOOL: Extracts the video path from the prompt, removes it from the query, reads the video data,
        builds the final prompt (with the video data and cleaned text), and calls Gemini.
        """
        # Extract the video path from the prompt (assumes a .mp4 file path exists)
        match = re.search(r"([\w\\/:.-]+\.mp4)", prompt)
        print(match)
        if not match:
            return "Error: No video file path found in the prompt."
        video_path = match.group(1)
        # Remove the video path from the prompt to get the cleaned query.
        cleaned_prompt = prompt.replace(video_path, "").strip()
        
        # Read video data from the extracted path.
        video_data = self.read_video_data(video_path)
        if video_data.startswith("Error"):
            return video_data
        
                # Build the final prompt with the required structure.
        final_prompt = (
            f"You are an aviation analyst. When summarizing a video, extract flight information:\n"
            f"- Flight company (top left corner)\n"
            f"- Flight number\n"
            f"- Registration\n"
            f"- Aircraft type\n"
            f"- Time\n"
            f"- Source and destination airport\n\n"
            f"Summarize in this format: **Flight {{flight_number}} of {{company}} from {{source}} to {{destination}} at {{time}}.**\n"
            f"Long blue lines indicate flight paths. List all countries crossed for each flight path.\n"
            f"For **suspicious activity**, check for **military zones, military aircraft, and air force identification.**\n\n"
            f"User request (without video path): {cleaned_prompt}\n"
            f"Summarize the flights in this video."
        )
        # Build the prompt according to the specified structure.
        prompt_list = [
            {
                "mime_type": "video/mp4",
                "data": video_data  # Base64-encoded video content
            },
            f"""
            You are an aviation analyst. When summarizing a video, extract flight information:
            - Flight company (top left corner)
            - Flight number
            - Registration
            - Aircraft type
            - Time
            - Source and destination airport
            Summarize in this format: **Flight {{flight_number}} of {{company}} from {{source}} to {{destination}} at {{time}}.**
            Long blue lines indicate flight paths. List all countries crossed for each flight path.
            For **suspicious activity**, check for **military zones, military aircraft, and air force identification.**

            {final_prompt}
            """
        ]
        # Call the Gemini model using generate_content()
        result = gemini_model.generate_content(contents=prompt_list, tools=[self.read_video_data])
        return result.text

    '''client = generativeai.Client()
    response = client.models.generate_content(
    model="gemini-2.0-flash-001",
    contents="What is the weather like in Boston?",
    config=types.GenerateContentConfig(tools=[read_video_data],)'''

# --- MasterAgent: orchestrator ---
class MasterAgent:
    def __init__(self, video_agent: VideoAgent): #, db_agent: DBAgent):
        self.video_agent = video_agent
        #self.db_agent = db_agent
    
    def extract_agent_plan(self, planning_response: str) -> list:
        """
        Attempts to parse planning_response as JSON.
        Expected JSON: an array of objects with keys 'agent', 'input', and 'reasoning'.
        If parsing fails, returns a default plan.
        """
        try:
            plan = json.loads(planning_response)
            if isinstance(plan, list):
                return plan
        except json.JSONDecodeError:
            # Try extracting JSON substring
            match = re.search(r'\[.*\]', planning_response, re.DOTALL)
            if match:
                try:
                    plan = json.loads(match.group(0))
                    if isinstance(plan, list):
                        return plan
                except json.JSONDecodeError:
                    pass
        # Fallback default plan.
        return [
            {
                "agent": "VideoAgent",
                "input": "Analyze the video at the provided path for flight information.",
                "reasoning": "The query includes a video file; therefore, video analysis is needed."
            },
            {
                "agent": "DBAgent",
                "input": "Based on the video analysis, query the CSV for additional flight-related details.",
                "reasoning": "To enrich the information extracted from the video."
            }
        ]
    
    def process(self, prompt: str) -> str:
        """
        The MasterAgent examines the prompt and determines which agents to invoke.
        If the prompt contains a video file path (e.g. ending with '.mp4'), it first calls VideoAgent.
        It prints its reasoning and the responses from each invoked agent.
        """
        outputs = [] 
              
        # Step 1: Use Gemini for reasoning and planning
        planning_prompt = (
            f"User Query: {prompt}\n"
            "Available Agents:\n"
            "1. VideoAgent: Analyzes video files to extract flight information.\n"
            "2. DBAgent: Queries flight-related data from a CSV database.\n"
            "Determine which agents to invoke and in what order to best address the query. "
            "Return a JSON array where each element is an object with keys 'agent', 'input', and 'reasoning'."
        )
        planning_response = gemini_model.generate_content(planning_prompt)
        outputs.append("Gemini Planning Response:\n" + planning_response.text)
        
        # Extract agent invocation plan from Gemini's response
        agent_plan = self.extract_agent_plan(planning_response.text)
        outputs.append("Extracted Agent Plan:\n" + json.dumps(agent_plan, indent=2, ensure_ascii=False))
        
        # Step 2: Execute the plan.
        for step in agent_plan:
            agent_name = step.get("agent")
            reasoning = step.get("reasoning")
            outputs.append(f"Master Reasoning: Invoking {agent_name} because: {reasoning}")            
            if agent_name.lower() == "videoagent":
                # For VideoAgent, we use the entire user_query. The VideoAgent will extract and remove the video path.
                video_response = self.video_agent.process(user_query)
                outputs.append("VideoAgent Response:\n" + video_response)
            #elif agent_name.lower() == "dbagent":
                #db_response = self.db_agent.process(step.get("input"))
                #outputs.append("DBAgent Response:\n" + db_response)
            else:
                outputs.append(f"Error: Unknown agent '{agent_name}'")
        
        return "\n\n".join(outputs)

class ContextAwareChatbot:
    def __init__(self):
        self.model = generativeai.GenerativeModel("gemini-1.5-flash")
        self.chat_history = [] 
        self.model.generate_content(SYSTEM_INSTRUCTION)
        
        
    def call_gemini_with_retry(self, prompt, retries=3, delay=2):
        """Calls Gemini AI with retry and delay to handle rate limits."""
        for attempt in range(retries):
            try:
                response = self.model.generate_content(prompt)
                time.sleep(delay)
                return response.text.strip() if response else "No relevant information found."
            except Exception as e:
                print(f"⚠️ API Error: {e} (Attempt {attempt+1}/{retries})")
                time.sleep(delay * (attempt + 1))

        return "⚠️ Error: Could not get a response. Please try again later."

    def intent_detection_agent(self, user_query):
        """Detects intent: Greeting, Question, Follow-up, or Exit."""
        prompt = f"""Classify the user's intent as one of the following:
        1. Greeting (hello, hi, hey)
        2. Question (asks for information)
        3. Summarize video (User will send the video encode to summarize).
        4. Follow-up (related to past conversation)
        5. Exit (goodbye, exit)
        Return only the category name.
        
        User Input: {user_query}
        """
        return self.call_gemini_with_retry(prompt)

    def research_agent(self, refined_query):
        """Finds relevant information using Gemini AI."""
        return self.call_gemini_with_retry(refined_query)

    def chat(self, user_query):
        """Handles chat requests."""
        intent = self.intent_detection_agent(user_query)

        if intent == "Greeting":
            # return "Hello! How can I assist you today? 😊"
            get_flight_data("ME425")
        
        if intent == "Summarize video":
            prompt = [
                {
                    "mime_type": "video/mp4",
                    "data": video_data 
                },
                """
                {SYSTEM_INSTRUCTION}
                
                Summarize the flights in this video.
                """
            ]
            return self.research_agent(prompt)

        response = self.research_agent(user_query)
        return response

def extract_flight_data(flight_id, html_code):
    """
    Extract flight history data from an HTML page and save it to a CSV file.
    
    Args:
        flight_id (str): The flight identifier.
        html_code (str): The HTML source code containing flight data.
    """
    soup = BeautifulSoup(html_code, 'html.parser')
    tbody = soup.find('table', {'id': 'tbl-datatable'}).find('tbody')
    
    if not tbody:
        print("No flight data found in the provided HTML.")
        return
    
    # Ensure the output directory exists
    output_dir = "data/flights_csv"
    os.makedirs(output_dir, exist_ok=True)
    output_file = os.path.join(output_dir, f"{flight_id}.csv")
    
    # Define CSV headers
    headers = ["Date", "From", "To", "Aircraft", "Flight Time", "STD", "ATD", "STA", "Status"]
    
    # Extract flight data
    rows = []
    for tr in tbody.find_all('tr', class_='data-row'):
        date = tr.find_all('td')[2].text.strip()
        from_airport = tr.find_all('td')[3].text.strip()
        to_airport = tr.find_all('td')[4].text.strip()
        aircraft = tr.find_all('td')[5].text.strip()
        flight_time = tr.find_all('td')[6].text.strip()
        std = tr.find_all('td')[7].text.strip()
        atd = tr.find_all('td')[8].text.strip()
        sta = tr.find_all('td')[9].text.strip()
        status = tr.find_all('td')[11].text.strip()
        
        rows.append([date, from_airport, to_airport, aircraft, flight_time, std, atd, sta, status])
    
    # Write data to CSV
    with open(output_file, mode='w', newline='', encoding='utf-8') as file:
        writer = csv.writer(file)
        writer.writerow(headers)
        writer.writerows(rows)
    
    print(f"Flight data saved successfully to {output_file}")

def get_flight_data(flight_id):
    """
    Check if the flight CSV file exists, otherwise scrape the data from FlightRadar24.
    
    :param flight_id: The ID of the flight (used for naming the CSV file)
    :return: The path to the CSV file
    """
    csv_file_path = f"data/flights_csv/{flight_id}.csv"
    
    if os.path.exists(csv_file_path):
        print(f"CSV file already exists: {csv_file_path}")
        return csv_file_path
    
    # Fetch HTML content from FlightRadar24
    url = f"https://www.flightradar24.com/data/flights/{flight_id.lower()}"
    response = requests.get(url, headers={"User-Agent": "Mozilla/5.0"})
    print(response.text)

    if response.status_code != 200:
        raise Exception(f"Failed to fetch flight data from {url}")
    
    # Extract and save data
    return extract_flight_data(flight_id, response.text)

chatbot = ContextAwareChatbot()
video_agent = VideoAgent()
master_agent = MasterAgent(video_agent)
user_query = ''

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/chat", methods=["POST"])
def chat():
    data = request.json
    user_query = data.get("message", "")
    # response = chatbot.chat(user_query)
    response = master_agent.process(user_query)
    return jsonify({"response": response})

if __name__ == "__main__":
    app.run(debug=True)
