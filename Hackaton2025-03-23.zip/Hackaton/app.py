from flask import Flask, request, jsonify, render_template
import google.generativeai as generativeai
import os
from dotenv import load_dotenv
import base64
import pandas as pd
from bs4 import BeautifulSoup
import requests
import csv
import json
import re

# Load API Key
load_dotenv()
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")

# Configure Gemini API
generativeai.configure(api_key=GEMINI_API_KEY)
gemini_model = generativeai.GenerativeModel("gemini-1.5-flash")

# Read the local video file
with open("data\\videos\\test.mp4", "rb") as video_file:
    video_data = base64.b64encode(video_file.read()).decode("utf-8")

# System instruction for the chatbot
SYSTEM_INSTRUCTION = """
You are an aviation analyst. When summarizing a video, extract flight information:
- Flight company (top left corner)
- Flight number
- Registration (most important!)
- Aircraft type
- Time
- Source and destination airport
Summarize in this format: **Flight {flight_number} of {company} from {source} to {destination} at {time} and registration number is {Registration}.**
Long blue lines indicate flight paths. List all countries crossed for each flight path.
For **suspicious activity**, check for **military zones, military aircraft, and air force identification.**
"""

app = Flask(__name__, template_folder="templates", static_folder="static")

# --- DBAgent: reads CSV and answers a query ---
class DBAgent:
    def __init__(self):
        pass

    def process(self, query: str) -> str:
        registration_list = self.extract_aircraft_registrations(query)
        print("Extracted Aircraft Registrations:", registration_list)

        if not registration_list:
            return "No valid aircraft registrations found in the query."

        summaries = []
        for registration in registration_list:
            try:
                output_file = self.get_aircraft_data(registration)
                if output_file:
                    summary = self.summarize_csv(output_file)
                    summaries.append(f"Summary for {registration}: {summary}\n")
            except Exception as e:
                print(f"Error processing {registration}: {e}")
                continue

        return "\n".join(summaries)

    def get_aircraft_data(self, registration: str) -> str:
        output_dir = "data/flights_csv"
        os.makedirs(output_dir, exist_ok=True)
        output_file = os.path.join(output_dir, f"{registration}.csv")

        if os.path.exists(output_file):
            print(f"File already exists: {output_file}")
            return output_file

        try:
            url = f"https://www.flightradar24.com/data/aircraft/{registration.lower()}"
            response = requests.get(url, headers={"User-Agent": "Mozilla/5.0"})
            if response.status_code != 200:
                raise Exception(f"Failed to fetch data from {url}")

            return self.extract_flight_data(registration, response.text)

        except Exception as e:
            print(f"Failed to scrape data for {registration}: {e}")
            return None

    def extract_flight_data(self, registration, html_code):
        soup = BeautifulSoup(html_code, 'html.parser')
        table = soup.find('table', {'id': 'tbl-datatable'})
        if not table:
            print("No flight data table found in the provided HTML.")
            return

        tbody = table.find('tbody')
        if not tbody:
            print("No flight data found in the provided HTML.")
            return

        output_dir = "data/flights_csv"
        os.makedirs(output_dir, exist_ok=True)
        output_file = os.path.join(output_dir, f"{registration}.csv")

        headers = ["Date", "From", "To", "Aircraft", "Flight Time", "STD", "ATD", "STA", "Status"]
        new_rows = []
        for tr in tbody.find_all('tr', class_='data-row'):
            tds = tr.find_all('td')
            new_rows.append([
                tds[2].text.strip(),
                tds[3].text.strip(),
                tds[4].text.strip(),
                tds[5].text.strip(),
                tds[6].text.strip(),
                tds[7].text.strip(),
                tds[8].text.strip(),
                tds[9].text.strip(),
                tds[11].text.strip()
            ])

        new_df = pd.DataFrame(new_rows, columns=headers)

        if os.path.exists(output_file):
            old_df = pd.read_csv(output_file)
            combined_df = pd.concat([old_df, new_df]).drop_duplicates()
        else:
            combined_df = new_df

        combined_df.to_csv(output_file, index=False, encoding='utf-8')
        print(f"Flight data saved and updated successfully to {output_file}")
        return output_file

    def extract_aircraft_registrations(self, query: str) -> list:
        prompt = (
            f"Extract all aircraft registration numbers from the following user input:\n\n"
            f"{query}\n\n"
            "Registration numbers are usually short codes like ZZ332, ZM409, PK-GJR, etc.\n"
            "Return only the registration numbers as a comma-separated list, with no explanation."
        )

        print(f"query: {query}")
        result = gemini_model.generate_content(prompt)
        response_text = result.text.strip()
        print(f"response_text: {response_text}")

        # Normalize and extract using pattern: two or more letters followed by 2–5 digits or vice versa
        response_text = response_text.replace("[", "").replace("]", "").replace("\"", "").replace("'", "")

        # This catches formats like ZZ332, ZM409, PK-GJR etc.
        registrations = re.findall(r'\b[A-Z]{2,3}-?[A-Z0-9]{2,5}\b', response_text.upper())
        return list(set(registrations))

    def summarize_csv(self, csv_path: str) -> str:
        try:
            df = pd.read_csv(csv_path)
            sample_text = df.head(100).to_csv(index=False)

            prompt = (
                f"Here is a sample of flight data in CSV format:\n\n"
                f"{sample_text}\n\n"
                "Please summarize the data, including flight trends, any unusual patterns, common routes, delays, or anomalies you detect and check for the route each countries flight over them."
            )

            result = gemini_model.generate_content(prompt)
            return result.text

        except Exception as e:
            return f"Failed to summarize CSV: {str(e)}"


# --- VideoAgent with a tool to read video data ---
class VideoAgent:
    def read_video_data(self, video_path: str) -> str:
        """
        Tool:
            Reads the video file from the given path and returns Base64-encoded content.        
        Args:
            video_path: str: Path to the video file.
    
        """
        try:
            # Read the local video file
            with open(video_path, "rb") as video_file:
                video_data = base64.b64encode(video_file.read()).decode("utf-8")
                return video_data
        except Exception as e:
            return f"Error reading video file: {e}"
    
    def process(self, prompt: str) -> str:
        """
        TOOL: Extracts the video path from the prompt, removes it from the query, reads the video data,
        builds the final prompt (with the video data and cleaned text), and calls Gemini.
        """
        # Extract the video path from the prompt (assumes a .mp4 file path exists)
        match = re.search(r"([\w\\/:.-]+\.mp4)", prompt)
        print(match)
        if not match:
            return "Error: No video file path found in the prompt."
        video_path = match.group(1)
        # Remove the video path from the prompt to get the cleaned query.
        cleaned_prompt = prompt.replace(video_path, "").strip()
        
        # Read video data from the extracted path.
        video_data = self.read_video_data(video_path)
        if video_data.startswith("Error"):
            return video_data
        
                # Build the final prompt with the required structure.
        final_prompt = (
            f"You are an aviation analyst. When summarizing a video, extract flight information:\n"
            f"- Flight company (top left corner)\n"
            f"- Flight number\n"
            f"- Registration\n"
            f"- Aircraft type\n"
            f"- Time\n"
            f"- Source and destination airport\n\n"
            f"Summarize in this format: **Flight {{flight_number}} of {{company}} from {{source}} to {{destination}} at {{time}} and registration number is {{registration}}.**\n"
            f"Long blue lines indicate flight paths. List all countries crossed for each flight path.\n"
            f"For **suspicious activity**, check for **military zones, military aircraft, and air force identification.**\n\n"
            f"User request (without video path): {cleaned_prompt}\n"
            f"Summarize the flights in this video."
        )
        # Build the prompt according to the specified structure.
        prompt_list = [
            {
                "mime_type": "video/mp4",
                "data": video_data  # Base64-encoded video content
            },
            f"""
            You are an aviation analyst. When summarizing a video, extract flight information:
            - Flight company (top left corner)
            - Flight number
            - Registration
            - Aircraft type
            - Time
            - Source and destination airport
            Summarize in this format: **Flight {{flight_number}} of {{company}} from {{source}} to {{destination}} at {{time}} and registration number is {{registration}}.**
            Long blue lines indicate flight paths. List all countries crossed for each flight path.
            For **suspicious activity**, check for **military zones, military aircraft, and air force identification.**

            {final_prompt}
            """
        ]
        # Call the Gemini model using generate_content()
        result = gemini_model.generate_content(contents=prompt_list, tools=[self.read_video_data])
        return result.text

    '''client = generativeai.Client()
    response = client.models.generate_content(
    model="gemini-2.0-flash-002",
    contents="What is the weather like in Boston?",
    config=types.GenerateContentConfig(tools=[read_video_data],)'''

# --- MasterAgent: orchestrator ---
class MasterAgent:
    def __init__(self, video_agent: VideoAgent): #, db_agent: DBAgent):
        self.video_agent = video_agent
        #self.db_agent = db_agent
    
    def extract_agent_plan(self, planning_response: str) -> list:
        """
        Attempts to parse planning_response as JSON.
        Expected JSON: an array of objects with keys 'agent', 'input', and 'reasoning'.
        If parsing fails, returns a default plan.
        """
        try:
            plan = json.loads(planning_response)
            if isinstance(plan, list):
                return plan
        except json.JSONDecodeError:
            # Try extracting JSON substring
            match = re.search(r'\[.*\]', planning_response, re.DOTALL)
            if match:
                try:
                    plan = json.loads(match.group(0))
                    if isinstance(plan, list):
                        return plan
                except json.JSONDecodeError:
                    pass
        # Fallback default plan.
        return [
            {
                "agent": "VideoAgent",
                "input": "Analyze the video at the provided path for flight information.",
                "reasoning": "The query includes a video file; therefore, video analysis is needed."
            },
            {
                "agent": "DBAgent",
                "input": "Based on the video analysis, query the CSV for additional flight-related details.",
                "reasoning": "To enrich the information extracted from the video."
            }
        ]
    
    def process(self, prompt: str) -> str:
        """
        The MasterAgent examines the prompt and determines which agents to invoke.
        If the prompt contains a video file path (e.g. ending with '.mp4'), it first calls VideoAgent.
        It prints its reasoning and the responses from each invoked agent.
        """
        outputs = [] 
              
        # Step 1: Use Gemini for reasoning and planning
        planning_prompt = (
            f"User Query: {prompt}\n"
            "Available Agents:\n"
            "1. VideoAgent: Analyzes video files to extract flight information.\n"
            "2. DBAgent: Queries flight-related data from a CSV database.\n"
            "Determine which agents to invoke and in what order to best address the query. "
            "Return a JSON array where each element is an object with keys 'agent', 'input', and 'reasoning'."
        )
        planning_response = gemini_model.generate_content(planning_prompt)
        outputs.append("Gemini Planning Response:\n" + planning_response.text)
        
        # Extract agent invocation plan from Gemini's response
        agent_plan = self.extract_agent_plan(planning_response.text)
        outputs.append("Extracted Agent Plan:\n" + json.dumps(agent_plan, indent=2, ensure_ascii=False))
        
        # Step 2: Execute the plan.
        for step in agent_plan:
            agent_name = step.get("agent")
            reasoning = step.get("reasoning")
            outputs.append(f"Master Reasoning: Invoking {agent_name} because: {reasoning}")            
            if agent_name.lower() == "videoagent":
                # For VideoAgent, we use the entire user_query. The VideoAgent will extract and remove the video path.
                video_response = self.video_agent.process(prompt)
                outputs.append("VideoAgent Response:\n" + video_response)
            elif agent_name.lower() == "dbagent":
                db_response = db_agent.process(step.get("input"))
                outputs.append("DBAgent Response:\n" + db_response)
            else:
                outputs.append(f"Error: Unknown agent '{agent_name}'")
        
        return "\n\n".join(outputs)

db_agent = DBAgent()
video_agent = VideoAgent()
master_agent = MasterAgent(video_agent)

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/chat", methods=["POST"])
def chat():
    data = request.json
    user_query = data.get("message", "")
    response = master_agent.process(user_query)
    return jsonify({"response": response})

if __name__ == "__main__":
    app.run(debug=True)