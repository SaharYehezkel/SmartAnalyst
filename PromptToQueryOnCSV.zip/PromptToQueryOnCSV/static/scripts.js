document.addEventListener("DOMContentLoaded", function () {
    loadQueryHistory();
    loadTables();
    checkDarkMode();
});

function toggleDarkMode() {
    let body = document.body;
    let button = document.getElementById("darkModeToggle");

    body.classList.toggle("dark-mode");
    let isDark = body.classList.contains("dark-mode");

    localStorage.setItem("darkMode", isDark);
    button.innerHTML = isDark ? "🌞 Light Mode" : "🌙 Dark Mode";
}

function checkDarkMode() {
    if (localStorage.getItem("darkMode") === "true") {
        document.body.classList.add("dark-mode");
        document.getElementById("darkModeToggle").innerHTML = "🌞 Light Mode";
    }
}

function uploadCSV() {
    let fileInput = document.getElementById("csvFile").files[0];
    let tableName = document.getElementById("tableName").value.trim().replace(/\s+/g, "_").toLowerCase();

    if (!fileInput || !tableName) {
        alert("Please select a CSV file and enter a table name!");
        return;
    }

    let formData = new FormData();
    formData.append("file", fileInput);
    formData.append("table_name", tableName);

    fetch("/upload", { method: "POST", body: formData })
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                alert("❌ Error: " + data.error);
            } else {
                alert(`✅ CSV uploaded! You can now query '${tableName}'`);
                document.getElementById("queryContainer").classList.remove("hidden");
                loadTables();
            }
        })
        .catch(error => console.error("Upload Error:", error));
}

function loadTables(forceRefresh = false) {
    let cacheBuster = forceRefresh ? `?t=${new Date().getTime()}` : ""; // Force fresh request

    fetch(`/tables` + cacheBuster)
        .then(response => response.json())
        .then(data => {
            let list = document.getElementById("tablesList");
            let container = document.getElementById("tablesContainer");

            if (data.tables && data.tables.length > 0) {
                list.innerHTML = "";
                data.tables.forEach(table => {
                    let datasetItem = document.createElement("div");
                    datasetItem.className = "dataset-item";
                    datasetItem.setAttribute("data-name", table);

                    datasetItem.innerHTML = `
                        <span onclick="loadSuggestions('${table}')">${table}</span>
                        <button class="remove-btn" onclick="removeDataset('${table}')">❌</button>
                    `;

                    list.appendChild(datasetItem);
                });

                container.classList.remove("hidden");
            } else {
                container.classList.add("hidden");
            }
        });
}


function removeDataset(tableName) {
    if (!confirm(`Are you sure you want to delete the dataset "${tableName}"?`)) return;

    fetch(`/delete_table`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ table_name: tableName })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert(`✅ Dataset "${tableName}" removed successfully!`);
            loadTables(); // Refresh the dataset list
        } else {
            alert(`❌ Error: ${data.error}`);
        }
    })
    .catch(error => console.error("Dataset Removal Error:", error));
}


/* Highlight Active Table When Clicked */
function setActiveTable(tableName) {
    let tables = document.querySelectorAll("#tablesList li");
    tables.forEach(t => t.classList.remove("active"));
    
    let selectedTable = Array.from(tables).find(t => t.textContent === tableName);
    if (selectedTable) {
        selectedTable.classList.add("active");
    }

    console.log(`Selected table: ${tableName}`);
}

function setQuery(query) {
    document.getElementById("sqlQuery").value = query;
}

function runQuery() {
    let query = document.getElementById("sqlQuery").value;
    if (!query) return alert("Enter a query!");

    saveQueryToHistory(query);

    fetch("/query", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ query })
    })
    .then(response => response.json())
    .then(data => {
        let results = document.getElementById("queryResults");

        if (data.length === 0) {
            results.innerHTML = "<p>No results found.</p>";
        } else {
            results.innerHTML = createTable(data);
            document.getElementById("downloadCSV").classList.remove("hidden");
        }

        document.getElementById("resultContainer").classList.remove("hidden");
    });
}

function createTable(data) {
    let columns = Object.keys(data[0]);

    let tableHTML = `
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        ${columns.map(col => `<th>${col}</th>`).join("")}
                    </tr>
                </thead>
                <tbody>
                    ${data.map(row => `
                        <tr>
                            ${columns.map(col => `<td>${row[col]}</td>`).join("")}
                        </tr>
                    `).join("")}
                </tbody>
            </table>
        </div>
    `;

    return tableHTML;
}

function downloadCSV() {
    let query = document.getElementById("sqlQuery").value;

    fetch("/query", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ query })
    })
    .then(response => response.json())
    .then(data => {
        if (data.length === 0) {
            alert("No data to download.");
            return;
        }

        let csvContent = "data:text/csv;charset=utf-8,";
        let columns = Object.keys(data[0]);
        csvContent += columns.join(",") + "\n";

        data.forEach(row => {
            let values = columns.map(col => row[col]);
            csvContent += values.join(",") + "\n";
        });

        let encodedUri = encodeURI(csvContent);
        let link = document.createElement("a");
        link.setAttribute("href", encodedUri);
        link.setAttribute("download", "query_results.csv");
        document.body.appendChild(link);
        link.click();
    });
}

function saveQueryToHistory(query) {
    let history = JSON.parse(localStorage.getItem("queryHistory")) || [];
    history.push(query);
    localStorage.setItem("queryHistory", JSON.stringify(history));
    loadQueryHistory();
}

function loadQueryHistory() {
    let history = JSON.parse(localStorage.getItem("queryHistory")) || [];
    document.getElementById("queryHistory").innerHTML = history.map(q => `<li onclick="setQuery('${q}')">${q}</li>`).join("");
}

function filterHistory() {
    let input = document.getElementById("searchQuery").value.toLowerCase();
    let historyItems = document.querySelectorAll("#queryHistory li");
    historyItems.forEach(item => item.style.display = item.innerText.toLowerCase().includes(input) ? "" : "none");
}

function showUploadModal() {
    document.getElementById("uploadModal").classList.remove("hidden");
}

function closeUploadModal() {
    document.getElementById("uploadModal").classList.add("hidden");
}

function removeDataset(tableName) {
    if (!confirm(`Are you sure you want to delete the dataset "${tableName}"?`)) return;

    fetch(`/delete_table`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ table_name: tableName })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert(`✅ Dataset "${tableName}" removed successfully!`);

            // Refresh the page to reflect the changes
            location.reload();
        } else {
            alert(`❌ Error: ${data.error}`);
        }
    })
    .catch(error => console.error("Dataset Removal Error:", error));
}

function generateSQL() {
    let userPrompt = document.getElementById("queryPrompt").value;

    if (!userPrompt.trim()) {
        alert("Please enter a question.");
        return;
    }

    fetch("/llm_sql", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt: userPrompt })
    })
    .then(response => response.json())
    .then(data => {
        if (data.generated_sql) {
            document.getElementById("sqlQuery").value = data.generated_sql; // Insert generated SQL into textarea
        } else {
            alert("Error: " + data.error);
        }
    })
    .catch(error => console.error("Error:", error));
}
