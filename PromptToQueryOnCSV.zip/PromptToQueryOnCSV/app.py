import re
import sqlite3
import pandas as pd
import duckdb
import google.generativeai as genai
from flask import Flask, request, jsonify, render_template

app = Flask(__name__)

# Load Gemini API Key
GEMINI_API_KEY = "AIzaSyCQqpBsYVbsDa7QqOC56B38PFZ8IPOgYhw"
if not GEMINI_API_KEY:
    raise ValueError("Gemini API Key is missing. Set it as an environment variable.")
genai.configure(api_key=GEMINI_API_KEY)

# SQLite Database File
DATABASE_FILE = "local_data.db"

# DuckDB connection (Still used for fast querying)
con = duckdb.connect(database=":memory:", read_only=False)

# Ensure database file and tables exist
def init_db():
    conn = sqlite3.connect(DATABASE_FILE)
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS datasets (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT UNIQUE NOT NULL,
            data TEXT NOT NULL
        )
    """)
    conn.commit()
    conn.close()

# Load datasets from SQLite into DuckDB when app starts
def load_datasets_from_db():
    conn = sqlite3.connect(DATABASE_FILE)
    cursor = conn.cursor()
    cursor.execute("SELECT name, data FROM datasets")
    datasets = cursor.fetchall()
    conn.close()

    for name, data in datasets:
        df = pd.read_json(data)  # Convert JSON back to DataFrame
        con.register(name, df)

# Detect CSV Encoding
def detect_encoding(file):
    raw_data = file.read(5000)
    result = chardet.detect(raw_data)
    file.seek(0)  # Reset file pointer after reading
    return result["encoding"]

# Initialize Database
init_db()
load_datasets_from_db()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload_csv():
    if 'file' not in request.files:
        return jsonify({"error": "No file provided"}), 400

    file = request.files['file']
    table_name = request.form.get("table_name", "").strip().replace(" ", "_").lower()

    if not table_name:
        return jsonify({"error": "Table name is required"}), 400

    encoding = detect_encoding(file)

    try:
        df = pd.read_csv(file, encoding=encoding)
        json_data = df.to_json()  # Convert DataFrame to JSON format

        # Save dataset in SQLite
        conn = sqlite3.connect(DATABASE_FILE)
        cursor = conn.cursor()
        cursor.execute("INSERT OR REPLACE INTO datasets (name, data) VALUES (?, ?)", (table_name, json_data))
        conn.commit()
        conn.close()

        # Register in DuckDB for immediate querying
        con.register(table_name, df)

        return jsonify({"message": f"CSV uploaded as '{table_name}'!", "table_name": table_name, "columns": list(df.columns)})

    except Exception as e:
        return jsonify({"error": f"Failed to read CSV: {str(e)}"}), 500

def get_database_schema():
    """
    Fetches all table names and their columns from the SQLite database.
    Returns a dictionary where keys are table names and values are lists of column names.
    """
    conn = sqlite3.connect(DATABASE_FILE)
    cursor = conn.cursor()
    cursor.execute("SELECT name, data FROM datasets")
    datasets = cursor.fetchall()
    conn.close()

    schema = {}
    for name, data in datasets:
        df = pd.read_json(data)  # Convert JSON back to DataFrame
        schema[name] = df.columns.tolist()  # Store column names for each dataset

    return schema


@app.route('/tables', methods=['GET'])
def list_tables():
    conn = sqlite3.connect(DATABASE_FILE)
    cursor = conn.cursor()
    cursor.execute("SELECT name FROM datasets")
    tables = [row[0] for row in cursor.fetchall()]
    conn.close()

    return jsonify({"tables": tables})

@app.route('/delete_table', methods=['POST'])
def delete_table():
    data = request.json
    table_name = data.get("table_name")

    # Remove from SQLite database
    conn = sqlite3.connect(DATABASE_FILE)
    cursor = conn.cursor()
    cursor.execute("DELETE FROM datasets WHERE name = ?", (table_name,))
    conn.commit()
    conn.close()

    # Drop table from DuckDB memory
    con.execute(f"DROP TABLE IF EXISTS {table_name}")

    return jsonify({"success": True})

@app.route('/query', methods=['POST'])
def query_csv():
    try:
        data = request.json
        sql_query = data.get("query", "")

        if not sql_query:
            return jsonify({"error": "Query is required"}), 400

        result_df = con.execute(sql_query).fetchdf()

        return jsonify(result_df.to_dict(orient="records"))

    except Exception as e:
        return jsonify({"error": str(e)}), 500
    
@app.route('/llm_sql', methods=['POST'])
def llm_generate_sql():
    try:
        data = request.json
        user_prompt = data.get("prompt", "").strip()
        
        if not user_prompt:
            return jsonify({"error": "Prompt is required"}), 400

        # Get available datasets and columns
        schema_info = get_database_schema()

        # Create a structured prompt for the LLM
        llm_prompt = f"""
        You are an AI SQL expert with knowledge of the following datasets:
        {schema_info}

        Given the user request: "{user_prompt}", generate the correct SQL query
        to extract the relevant data.
        Only return the SQL query and nothing else.
        """

        # Send prompt to Gemini API
        model = genai.GenerativeModel("gemini-1.5-flash")
        response = model.generate_content(llm_prompt)
        generated_sql = response.text.strip()

        cleaned_sql = re.sub(r"```sql|```", "", generated_sql).strip()

        return jsonify({"generated_sql": cleaned_sql})

    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)
