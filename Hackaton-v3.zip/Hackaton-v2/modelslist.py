import google.generativeai as genai
from dotenv import load_dotenv
import os

# Load your API key from environment
load_dotenv()
genai.configure(api_key=os.getenv("GEMINI_API_KEY"))

# List models
models = genai.list_models()

# Print all model names
for model in models:
    print(model.name)


