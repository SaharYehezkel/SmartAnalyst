console.log("✅ scripts.js loaded");

function clearUserInput() {
    document.getElementById("user-input").value = "";
}

function renderMarkdownWithEmoji(text) {
    const markdown = marked.parse(text); // Convert Markdown to HTML
    const withEmojis = twemoji.parse(markdown, {
        folder: 'svg',
        ext: '.svg'
    });
    return withEmojis;
}

function sendMessage() {
    const sendBtn = document.getElementById("send-btn");
    const voiceBtn = document.getElementById("mic-btn");
    const spinner = document.getElementById("spinner");

    let userMessage = document.getElementById("user-input").value.trim();
    if (!userMessage) return;

    // Disable button + show spinner
    sendBtn.style.display = "none";
    voiceBtn.style.display = "none";
    spinner.style.display = "inline-block";

    let chatBox = document.getElementById("chat-box");
    let reasoningBox = document.getElementById("reasoning-box"); 
    let userBubble = document.createElement("div");
    
    userBubble.classList.add("message", "user-message");
    userBubble.innerHTML = renderMarkdownWithEmoji(userMessage);
    chatBox.appendChild(userBubble);
    chatBox.scrollTop = chatBox.scrollHeight;
 
    clearUserInput();
 
    fetch("/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: userMessage })
    })
    .then(response => response.json())
    .then(data => {
        // AI response bubble
        let aiBubble = document.createElement("div");
        aiBubble.classList.add("message", "gemini-message");
        aiBubble.innerHTML = renderMarkdownWithEmoji(data.response);
        chatBox.appendChild(aiBubble);
 
        // Reasoning box (if exists in the data)
        if (data.reasoning && reasoningBox) {
            reasoningBox.innerHTML = `<div class="formatted-message">${data.reasoning}</div>`;
        }
 
        chatBox.scrollTop = chatBox.scrollHeight;
    })
    .finally(() => {
        // Re-enable button + hide spinner
        sendBtn.style.display = "inline-block";
        voiceBtn.style.display = "inline-block";
        spinner.style.display = "none";
    })
    .catch(error => console.error("Error:", error));
}


function startVoiceInput() {
    if (!('webkitSpeechRecognition' in window)) {
        alert("Speech recognition not supported in this browser.");
        return;
    }

    const recognition = new webkitSpeechRecognition();
    recognition.lang = "en-US";
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;

    recognition.onstart = () => {
        document.getElementById("mic-btn").innerText = "🎤 Listening...";
    };

    recognition.onresult = (event) => {
        const transcript = event.results[0][0].transcript;
        document.getElementById("user-input").value = transcript;
    };

    recognition.onerror = (event) => {
        alert("Voice input failed: " + event.error);
    };

    recognition.onend = () => {
        document.getElementById("mic-btn").innerText = "🎤";
    };

    recognition.start();
}

// Function to display system messages
function displaySystemMessage(text) {
    let chatBox = document.getElementById("chat-box");
    let systemBubble = document.createElement("div");
    systemBubble.classList.add("message", "system-message");
    systemBubble.innerHTML = renderMarkdownWithEmoji(text); // ✅
    chatBox.appendChild(systemBubble);
    chatBox.scrollTop = chatBox.scrollHeight;
}

function handleKeyPress(event) {
    if (event.key === "Enter") {
        sendMessage();
    }
}
