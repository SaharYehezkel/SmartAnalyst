from flask import Flask, request, jsonify, render_template
import google.generativeai as genai
import os
import time
from dotenv import load_dotenv
import base64
import pandas as pd
from bs4 import BeautifulSoup
import requests
import csv

# Load API Key
load_dotenv()
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")

# Configure Gemini API
genai.configure(api_key=GEMINI_API_KEY)

# Read the local video file
with open("data\\videos\\test.mp4", "rb") as video_file:
    video_data = base64.b64encode(video_file.read()).decode("utf-8")

# System instruction for the chatbot
SYSTEM_INSTRUCTION = """
You are an aviation analyst. When summarizing a video, extract flight information:
- Flight company (top left corner)
- Flight number
- Registration
- Aircraft type
- Time
- Source and destination airport
Summarize in this format: **Flight {flight_number} of {company} from {source} to {destination} at {time}.**
Long blue lines indicate flight paths. List all countries crossed for each flight path.
For **suspicious activity**, check for **military zones, military aircraft, and air force identification.**
"""

app = Flask(__name__, template_folder="templates", static_folder="static")

class ContextAwareChatbot:
    def __init__(self):
        self.model = genai.GenerativeModel("gemini-1.5-flash")
        self.chat_history = [] 
        self.model.generate_content(SYSTEM_INSTRUCTION)
        
        
    def call_gemini_with_retry(self, prompt, retries=3, delay=2):
        """Calls Gemini AI with retry and delay to handle rate limits."""
        for attempt in range(retries):
            try:
                response = self.model.generate_content(prompt)
                time.sleep(delay)
                return response.text.strip() if response else "No relevant information found."
            except Exception as e:
                print(f"⚠️ API Error: {e} (Attempt {attempt+1}/{retries})")
                time.sleep(delay * (attempt + 1))

        return "⚠️ Error: Could not get a response. Please try again later."

    def intent_detection_agent(self, user_input):
        """Detects intent: Greeting, Question, Follow-up, or Exit."""
        prompt = f"""Classify the user's intent as one of the following:
        1. Greeting (hello, hi, hey)
        2. Question (asks for information)
        3. Summarize video (User will send the video encode to summarize).
        4. Follow-up (related to past conversation)
        5. Exit (goodbye, exit)
        Return only the category name.
        
        User Input: {user_input}
        """
        return self.call_gemini_with_retry(prompt)

    def research_agent(self, refined_query):
        """Finds relevant information using Gemini AI."""
        return self.call_gemini_with_retry(refined_query)

    def chat(self, user_input):
        """Handles chat requests."""
        intent = self.intent_detection_agent(user_input)

        if intent == "Greeting":
            # return "Hello! How can I assist you today? 😊"
            get_flight_data("ME425")
        
        if intent == "Summarize video":
            prompt = [
                {
                    "mime_type": "video/mp4",
                    "data": video_data 
                },
                """
                {SYSTEM_INSTRUCTION}
                
                Summarize the flights in this video.
                """
            ]
            return self.research_agent(prompt)

        response = self.research_agent(user_input)
        return response

chatbot = ContextAwareChatbot()

def extract_flight_data(flight_id, html_code):
    """
    Extract flight history data from an HTML page and save it to a CSV file.
    
    Args:
        flight_id (str): The flight identifier.
        html_code (str): The HTML source code containing flight data.
    """
    soup = BeautifulSoup(html_code, 'html.parser')
    tbody = soup.find('table', {'id': 'tbl-datatable'}).find('tbody')
    
    if not tbody:
        print("No flight data found in the provided HTML.")
        return
    
    # Ensure the output directory exists
    output_dir = "data/flights_csv"
    os.makedirs(output_dir, exist_ok=True)
    output_file = os.path.join(output_dir, f"{flight_id}.csv")
    
    # Define CSV headers
    headers = ["Date", "From", "To", "Aircraft", "Flight Time", "STD", "ATD", "STA", "Status"]
    
    # Extract flight data
    rows = []
    for tr in tbody.find_all('tr', class_='data-row'):
        date = tr.find_all('td')[2].text.strip()
        from_airport = tr.find_all('td')[3].text.strip()
        to_airport = tr.find_all('td')[4].text.strip()
        aircraft = tr.find_all('td')[5].text.strip()
        flight_time = tr.find_all('td')[6].text.strip()
        std = tr.find_all('td')[7].text.strip()
        atd = tr.find_all('td')[8].text.strip()
        sta = tr.find_all('td')[9].text.strip()
        status = tr.find_all('td')[11].text.strip()
        
        rows.append([date, from_airport, to_airport, aircraft, flight_time, std, atd, sta, status])
    
    # Write data to CSV
    with open(output_file, mode='w', newline='', encoding='utf-8') as file:
        writer = csv.writer(file)
        writer.writerow(headers)
        writer.writerows(rows)
    
    print(f"Flight data saved successfully to {output_file}")


def get_flight_data(flight_id):
    """
    Check if the flight CSV file exists, otherwise scrape the data from FlightRadar24.
    
    :param flight_id: The ID of the flight (used for naming the CSV file)
    :return: The path to the CSV file
    """
    csv_file_path = f"data/flights_csv/{flight_id}.csv"
    
    if os.path.exists(csv_file_path):
        print(f"CSV file already exists: {csv_file_path}")
        return csv_file_path
    
    # Fetch HTML content from FlightRadar24
    url = f"https://www.flightradar24.com/data/flights/{flight_id.lower()}"
    response = requests.get(url, headers={"User-Agent": "Mozilla/5.0"})
    print(response.text)

    if response.status_code != 200:
        raise Exception(f"Failed to fetch flight data from {url}")
    
    # Extract and save data
    return extract_flight_data(flight_id, response.text)

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/chat", methods=["POST"])
def chat():
    data = request.json
    user_input = data.get("message", "")
    response = chatbot.chat(user_input)
    return jsonify({"response": response})

if __name__ == "__main__":
    app.run(debug=True)
