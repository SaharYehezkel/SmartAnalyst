function clearUserInput() {
    document.getElementById("user-input").value = "";
}

function sendMessage() {
    let userMessage = document.getElementById("user-input").value.trim();
    if (!userMessage) return;

    let chatBox = document.getElementById("chat-box");

    // Add user message bubble
    let userBubble = document.createElement("div");
    userBubble.classList.add("message", "user-message");
    userBubble.innerText = userMessage;
    chatBox.appendChild(userBubble);

    // Scroll to the bottom
    chatBox.scrollTop = chatBox.scrollHeight;

    // System instructions handling
    if (userMessage.toLowerCase() === "/help") {
        displaySystemMessage("📜 **Available Commands:** <br> /help - Show this message <br> /rules - Display system rules");
        clearUserInput();
        return;
    } else if (userMessage.toLowerCase() === "/rules") {
        displaySystemMessage("⚠️ **System Rules:** <br> - Be respectful <br> - No spamming <br> - Do not share sensitive information.");
        clearUserInput();
        return;
    }

    clearUserInput();

    // API call for normal chat
    fetch("/chat", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({ message: userMessage })
    })
    .then(response => response.json())
    .then(data => {
        let aiBubble = document.createElement("div");
        aiBubble.classList.add("message", "gemini-message");
        aiBubble.innerHTML = data.response;
        chatBox.appendChild(aiBubble);
        chatBox.scrollTop = chatBox.scrollHeight;
    })
    .catch(error => console.error("Error:", error));
}

// Function to display system messages
function displaySystemMessage(text) {
    let chatBox = document.getElementById("chat-box");
    let systemBubble = document.createElement("div");
    systemBubble.classList.add("message", "system-message");
    systemBubble.innerHTML = text;
    chatBox.appendChild(systemBubble);
    chatBox.scrollTop = chatBox.scrollHeight;
}

function handleKeyPress(event) {
    if (event.key === "Enter") {
        sendMessage();
    }
}