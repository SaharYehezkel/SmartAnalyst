import os
import re
import base64
import cv2
import numpy as np
import pandas as pd
import requests
from bs4 import BeautifulSoup
#import pandas as pd
import json
import google.generativeai as generativeai
from google.generativeai.types import FunctionDeclaration, Tool
import tempfile
from datetime import datetime
from collections import deque
from flask import Flask, request, jsonify, render_template

# --- Configure Gemini ---
# Make sure your environment variable GOOGLE_API_KEY is set, or set it directly below.
generativeai.configure(api_key=os.getenv("GOOGLE_API_KEY"))
# Create a Gemini model object.
# We assume the model ID is "gemini-1.5-flash".
# Note: The API provides a generate_content() method.
gemini_model = generativeai.GenerativeModel("gemini-2.0-flash-001")

app = Flask(__name__, template_folder="templates", static_folder="static")

def gemini_predict(prompt) -> str:
    """
    Calls the Gemini model using generate_content() with the given prompt.
    Accepts either a list (for structured prompts) or a string.
    """
    result = gemini_model.generate_content(prompt=prompt)
    return result

# --- Memory class for maintaining conversation context ---
class Memory:
    def __init__(self, max_interactions=10):
        self.interactions = deque(maxlen=max_interactions)
        self.metadata = {}

    def add_interaction(self, role, message, metadata=None):
        """
        Adds an interaction to the memory.
        
        Args:
            role: str: The role of the sender (e.g., "user", "agent", "system")
            message: str: The content of the message
            metadata: dict: Any additional metadata to store with this interaction
        """
        timestamp = datetime.now().isoformat()
        interaction = {
            "role": role,
            "message": message,
            "timestamp": timestamp,
            "metadata": metadata or {}
        }
        self.interactions.append(interaction)
    
    def get_conversation_history(self, format_type="text", max_tokens=None):
        """
        Returns the conversation history in the specified format.
        
        Args:
            format_type: str: The format to return the history in ("text", "json", "messages")
            max_tokens: int: Maximum number of tokens to include (if None, include all)
            
        Returns:
            The conversation history in the specified format
        """
        if format_type == "json":
            return json.dumps(list(self.interactions))
        elif format_type == "messages":
            return list(self.interactions)
        else:  # Default to text format
            history = []
            for interaction in self.interactions:
                history.append(f"{interaction['role'].capitalize()}: {interaction['message']}")
            return "\n\n".join(history)
    
    def summarize_context(self):
        """
        Creates a summary of the current conversation context.
        
        Returns:
            str: A summary of the current context
        """
        if not self.interactions:
            return "No previous context."
        
        prompt = (
            "Summarize the following conversation concisely, focusing on key information and decisions:\n\n"
            f"{self.get_conversation_history()}"
        )
        
        result = gemini_model.generate_content(prompt)
        return result.text
    
    def add_metadata(self, key, value):
        """Adds or updates metadata for the conversation"""
        self.metadata[key] = value
    
    def get_metadata(self, key, default=None):
        """Retrieves metadata for the conversation"""
        return self.metadata.get(key, default)

# --- Chat class for managing conversational interfaces ---
class Chat:
    def __init__(self, agent_name, memory=None, system_prompt=None):
        self.agent_name = agent_name
        self.memory = memory or Memory()
        if system_prompt:
            self.memory.add_interaction("system", system_prompt)
    
    def add_system_message(self, message):
        """Adds a system message to the conversation history"""
        self.memory.add_interaction("system", message)
    
    def add_user_message(self, message):
        """Adds a user message to the conversation history"""
        self.memory.add_interaction("user", message)
    
    def add_agent_message(self, message):
        """Adds an agent message to the conversation history"""
        self.memory.add_interaction("agent", message)
    
    def get_context_prompt(self, include_agent_name=True):
        """
        Creates a prompt with the conversation context to provide to the model
        
        Returns:
            str: A prompt string with context
        """
        context = self.memory.get_conversation_history()
        agent_prefix = f"You are the {self.agent_name}. " if include_agent_name else ""
        
        return (
            f"{agent_prefix}Here is the conversation history:\n\n"
            f"{context}\n\n"
            "Use this context to inform your response to the current query."
        )
    
    def generate_response(self, query, include_context=True, system_instruction=None):
        """
        Generates a response using the Gemini model with conversation context
        
        Args:
            query: str: The current user query
            include_context: bool: Whether to include conversation context
            system_instruction: str: Additional system instruction for this query
            
        Returns:
            str: The generated response
        """
        prompt_parts = []
        
        # Add system instruction if provided
        if system_instruction:
            prompt_parts.append(system_instruction)
        
        # Add conversation context if requested
        if include_context and len(self.memory.interactions) > 0:
            prompt_parts.append(self.get_context_prompt())
        
        # Add the current query
        prompt_parts.append(f"User: {query}\n\n{self.agent_name} response:")
        
        # Join all parts with newlines
        prompt = "\n\n".join(prompt_parts)
        
        # Call Gemini
        result = gemini_model.generate_content(prompt)
        response = result.text
        
        # Save both query and response to memory
        self.add_user_message(query)
        self.add_agent_message(response)
        
        return response


# --- VideoAgent with a tool to read video data ---
class VideoAgent:
    def __init__(self):
        system_prompt = (
            "You are a VideoAgent specialized in analyzing aviation videos. "
            "You can extract flight information, detect visual elements, and process video frames. "
            "You can extract frames at specific timestamps and analyze regions of interest in the video."
        )
        self.chat = Chat("VideoAgent", system_prompt=system_prompt)
        self.reasoning = []  # Store reasoning separately

    
    def read_video_data(self, video_path: str) -> str:
        """
        Tool:
            Reads the video file from the given path and returns Base64-encoded content.        
        Args:
            video_path: str: Path to the video file.
    
        """
        try:
            # Read the local video file
            with open(video_path, "rb") as video_file:
                video_data = base64.b64encode(video_file.read()).decode("utf-8")
                return video_data
        except Exception as e:
            return f"Error reading video file: {e}"
    
    # --- Helper functions for video processing tools ---
    def extract_frame(self, video_path: str, time_stamp: str, output_image: str) -> bool:
        """
        Extracts a frame from the video at the given time (mm:ss) and saves it.
        Returns True if successful.
        """
        try:
            parts = time_stamp.strip().split(":")
            if len(parts) != 2:
                return False
            minutes, seconds = int(parts[0]), int(parts[1])
            millisec = (minutes * 60 + seconds) * 1000

            cap = cv2.VideoCapture(video_path)
            if not cap.isOpened():
                return False
            cap.set(cv2.CAP_PROP_POS_MSEC, millisec)
            success, frame = cap.read()
            cap.release()
            if success:
                cv2.imwrite(output_image, frame)
            return success
        except Exception as e:
            print(f"Error in extract_frame: {e}")
            return False

    def crop_to_polygon(self, image, vertices):
        """
        Creates a mask from the polygon vertices, applies it to the image,
        and then crops the image to the polygon's bounding rectangle.
        """
        mask = np.zeros(image.shape[:2], dtype=np.uint8)
        pts = np.array(vertices, np.int32).reshape((-1, 1, 2))
        cv2.fillPoly(mask, [pts], 255)
        masked_image = cv2.bitwise_and(image, image, mask=mask)
        x, y, w, h = cv2.boundingRect(pts)
        cropped_image = masked_image[y:y+h, x:x+w]
        return cropped_image

    def extract_purple_polygon_edges(self, image):
        """
        Converts the image to HSV, applies a purple mask, blurs it, runs Canny edge detection,
        finds contours, and approximates the largest one to a polygon.
        Returns the polygon vertices and the edge image.
        """
        hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
        lower_purple = np.array([130, 50, 50])
        upper_purple = np.array([160, 255, 255])
        mask = cv2.inRange(hsv, lower_purple, upper_purple)
        blurred = cv2.GaussianBlur(mask, (5, 5), 0)
        edges = cv2.Canny(blurred, 50, 150)
        contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        if not contours:
            print("No contours found")
            return None, edges
        image_area = image.shape[0] * image.shape[1]
        min_area = 0.005 * image_area
        large_contours = [cnt for cnt in contours if cv2.contourArea(cnt) > min_area]
        largest_contour = max(large_contours, key=cv2.contourArea) if large_contours else max(contours, key=cv2.contourArea)
        arc_length = cv2.arcLength(largest_contour, True)
        epsilon = 0.005 * arc_length
        approx = cv2.approxPolyDP(largest_contour, epsilon, True)
        vertices = [tuple(pt[0]) for pt in approx]
        return vertices, edges

    def extract_polygon(self, video_path: str, time_stamp: str) -> dict:
        """
        Extracts a frame at the given time, detects a purple polygon,
        crops the area within the polygon, saves the cropped image,
        and returns a dict with the cropped image filename and detected vertices.
        """
        output_image = "extracted_frame_for_polygon.jpg"
        if not self.extract_frame(video_path, time_stamp, output_image):
            return {"error": "Could not extract frame at the specified time."}
        
        image = cv2.imread(output_image)
        if image is None:
            return {"error": "Error loading the extracted frame."}
        
        vertices, edges = self.extract_purple_polygon_edges(image)
        if vertices is not None:
            pts = np.array(vertices, np.int32).reshape((-1, 1, 2))
            cv2.polylines(image, [pts], isClosed=True, color=(255, 0, 255), thickness=3)
            cropped = self.crop_to_polygon(image, vertices)
            cropped_output_path = "cropped_polygon_area.jpg"
            cv2.imwrite(cropped_output_path, cropped)
            return {
                "cropped_image": cropped_output_path,
                "vertices": vertices
            }
        else:
            return {"error": "No suitable purple polygon detected."}
    
    def encode_image_to_base64(self, image_path: str) -> str:
        """
        Reads an image file and returns its Base64-encoded string.
        """
        try:
            with open(image_path, "rb") as f:
                image_bytes = f.read()
            return base64.b64encode(image_bytes).decode("utf-8")
        except Exception as e:
            return f"Error encoding image: {e}"
    
    def process(self, prompt: str) -> str:
        """
        Processes the prompt by:   
        1. Building an initial analysis prompt.
        2. Calling Gemini with the prompt list and a list of tools.
        3. If Gemini chooses to invoke a tool (e.g., extract_polygon), the tool is automatically called.
        4. After the tool returns its result, VideoAgent calls Gemini again with a follow-up prompt to investigate the tool output.
        5. Aggregates all responses and returns a final answer.
        """
        self.reasoning = []  # Reset reasoning for this request
        # Extract the video path from the prompt (assumes a .mp4 file path exists)
        match = re.search(r"([\w\\/:.-]+\.mp4)", prompt)
        if not match:
            # If no video path is found, treat as a regular chat message
            return self.chat.generate_response(prompt)
            
        video_path = match.group(1)
        
        # Store video path in memory for future reference
        self.chat.memory.add_metadata("last_video_path", video_path)
        
        # Remove the video path from the prompt to get the cleaned query.
        cleaned_prompt = prompt.replace(video_path, "").strip()
        
        # Read video data from the extracted path.
        video_data = self.read_video_data(video_path)
        if video_data.startswith("Error"):
            self.chat.add_system_message(f"Error processing video: {video_data}")
            return self.chat.generate_response("I encountered an error with the video file. " + video_data)
        
        # CHANGED: Modified the analysis prompt to first analyze the whole video and explain tool reasoning
        analysis_prompt = (
            f"You are an aviation analyst. When summarizing a video for flight information, follow these steps:\n"
            f"Long blue lines indicate flight paths. List all countries crossed for each flight path.\n"
            """Airplane icon in red color indicates a flight which the user interested in, in that case an information box on that airplane flight will open
            on the left side of the screen. in the left upper side of this information box you can detect the REGISTRATION, extract the registration detail under this text."""
            f"Identify the flight number and the aircraft type of the flight the user interested in .\n\n"
            f"extract flight information in this structure:\n"
            f"- Flight company: \n"
            f"- Flight number: \n"
            f"- Registration: \n"
            f"- Aircraft type: \n"
            f"- Time: \n"
            f"- Source and destination airport: \n\n"
            f"User request (without video path): {cleaned_prompt}\n"
            f"First, provide a complete summary of the flights in this video in the structure given above. giva a concise summary.\n"
            """If you detect a purple polygon in the video, use the extract_polygon tool, with the timestamp (mm:ss) 
            when the polygon is fully connected to a closed shape for the first time.\n"""            
            f"continue to analyze the video, after the result from extract_polygon tool."
            f"the purple polygon is a region of interest in the video. "
            f"detect if there are any other tools needed to analyze the video."
        )
        
        # Add context to the analysis prompt if we have conversation history
        context_summary = ""
        if len(self.chat.memory.interactions) > 1:  # If we have previous interactions
            context_summary = f"\n\nPrevious conversation context: {self.chat.memory.summarize_context()}"
        
        # Build the prompt according to the specified structure.
        prompt_list = [
            {
                "mime_type": "video/mp4",
                "data": video_data  # Base64-encoded video content
            },            
            analysis_prompt + context_summary           
        ]
        
        # Define the function declaration - using video_path
        extract_polygon_tool = FunctionDeclaration(
            name="extract_polygon",
            description="Extracts a frame from a video at a specific timestamp, detects a purple polygon, and crops the area within it",
            parameters={
                "type": "object",
                "properties": {
                    "video_path": {
                        "type": "string",
                        "description": "Path to the video file"
                    },
                    "time_stamp": {
                        "type": "string",
                        "description": "Timestamp in the video to extract the frame (format: MM:SS)"
                    }
                },
                "required": ["video_path", "time_stamp"]
            }
        )

        # Create a Tool object from the function declaration
        tools = [Tool(function_declarations=[extract_polygon_tool])]

        # Store all response parts
        response_parts = []
        
        # Call the model with the tools
        initial_analysis = gemini_model.generate_content(
            contents=prompt_list,
            tools=tools,
            tool_config={"function_calling_config": {"mode": "auto"}}
        )

        # Store the original user query in memory
        self.chat.add_user_message(prompt)
        
        # CHANGED: Modified response processing to separate initial analysis from tool results
        has_tool_calls = False
        initial_analysis_text = ""
        tool_responses = []
        response_parts = []  # Ensure this is initialized

        # Process the response
        for part in initial_analysis.parts:
            if hasattr(part, 'text') and part.text:
                print(part.text)
                # Store the initial analysis text separately
                initial_analysis_text = part.text
                response_parts.append(initial_analysis_text)
            elif hasattr(part, 'function_call'):
                has_tool_calls = True
                function_name = part.function_call.name
                function_args = part.function_call.args
                
                if function_name == "extract_polygon":
                    time_stamp = function_args.get("time_stamp")
                    
                    # CHANGED: Add reasoning about tool invocation
                    tool_reasoning = f"\n\nTOOL INVOCATION: Based on the video analysis, I'm extracting the purple polygon at {time_stamp} for detailed examination."
                    self.reasoning.append(tool_reasoning)
                    
                    # Use the original video path we extracted from the prompt
                    result = self.extract_polygon(video_path=video_path, time_stamp=time_stamp)
                    
                    # Store this tool usage in memory
                    self.chat.memory.add_metadata(f"polygon_extraction_{time_stamp}", result)
                    
                    # If we have successfully extracted the polygon, get base64 of the cropped image
                    if "cropped_image" in result and not result.get("error"):
                        cropped_image_path = result["cropped_image"]
                        image_base64 = self.encode_image_to_base64(cropped_image_path)
                        
                        # Then feed the result back to Gemini for further analysis
                        follow_up_prompt = [
                            {
                                "mime_type": "image/jpeg",
                                "data": image_base64
                            },
                            f"This image shows the detected polygon from the video at timestamp {time_stamp}. " 
                            f"The polygon vertices are at these coordinates: {result['vertices']}. "
                            #f"Please analyze this polygon area and tell me what you can observe within it. "
                            #f"Identify any text, numbers, symbols, or significant features."
                            f"Your main goal is to detect precisely how many airplane icons are present inside the purple polygon area. please count them."
                            f"giva a concise summary"
                        ]
                        
                        follow_up_analysis = gemini_model.generate_content(follow_up_prompt)
                        
                        self.reasoning.append(f"Follow-up analysis of polygon extracted at {time_stamp}:")
                        self.reasoning.append(follow_up_analysis.text)
                        
                        tool_responses.append(follow_up_analysis.text)
                    else:
                        #Add error to reasoning
                        self.reasoning.append(f"Failed to extract polygon: {result.get('error', 'Unknown error')}")
                        tool_responses.append(f"Failed to extract polygon: {result.get('error', 'Unknown error')}")
        
        # CHANGED: Only include tool responses in the final output if tools were called
        if has_tool_calls:
            if response_parts:  # Check if the list is not empty
                all_parts = [response_parts[0]] + tool_responses
            else:
                all_parts = ["Initial analysis unavailable"] + tool_responses
            full_response = "\n\n".join(all_parts)
        else:
            full_response = initial_analysis_text
        
        # Save the response to memory
        self.chat.add_agent_message(full_response)
        
        return full_response

# --- DBAgent: reads CSV and answers a query ---
class DBAgent:
    def __init__(self):
        pass

    def process(self, query: str) -> str:
        registration_list = self.extract_aircraft_registrations(query)
        print("Extracted Aircraft Registrations:", registration_list)

        if not registration_list:
            return "No valid aircraft registrations found in the query."

        summaries = []
        for registration in registration_list:
            try:
                output_file = self.get_aircraft_data(registration)
                if output_file:
                    summary = self.summarize_csv(output_file)
                    summaries.append(f"Summary for {registration}: {summary}\n")
            except Exception as e:
                print(f"Error processing {registration}: {e}")
                continue

        return "\n".join(summaries)

    def get_aircraft_data(self, registration: str) -> str:
        output_dir = "data/flights_csv"
        os.makedirs(output_dir, exist_ok=True)
        output_file = os.path.join(output_dir, f"{registration}.csv")

        if os.path.exists(output_file):
            print(f"File already exists: {output_file}")
            return output_file

        try:
            url = f"https://www.flightradar24.com/data/aircraft/{registration.lower()}"
            response = requests.get(url, headers={"User-Agent": "Mozilla/5.0"},verify=False)
            if response.status_code != 200:
                raise Exception(f"Failed to fetch data from {url}")

            return self.extract_flight_data(registration, response.text)

        except Exception as e:
            print(f"Failed to scrape data for {registration}: {e}")
            return None

    def extract_flight_data(self, registration, html_code):
        soup = BeautifulSoup(html_code, 'html.parser')
        table = soup.find('table', {'id': 'tbl-datatable'})
        if not table:
            print("No flight data table found in the provided HTML.")
            return

        tbody = table.find('tbody')
        if not tbody:
            print("No flight data found in the provided HTML.")
            return

        output_dir = "data/flights_csv"
        os.makedirs(output_dir, exist_ok=True)
        output_file = os.path.join(output_dir, f"{registration}.csv")

        headers = ["Date", "From", "To", "Aircraft", "Flight Time", "STD", "ATD", "STA", "Status"]
        new_rows = []
        for tr in tbody.find_all('tr', class_='data-row'):
            tds = tr.find_all('td')
            new_rows.append([
                tds[2].text.strip(),
                tds[3].text.strip(),
                tds[4].text.strip(),
                tds[5].text.strip(),
                tds[6].text.strip(),
                tds[7].text.strip(),
                tds[8].text.strip(),
                tds[9].text.strip(),
                tds[11].text.strip()
            ])

        new_df = pd.DataFrame(new_rows, columns=headers)

        if os.path.exists(output_file):
            old_df = pd.read_csv(output_file)
            combined_df = pd.concat([old_df, new_df]).drop_duplicates()
        else:
            combined_df = new_df

        combined_df.to_csv(output_file, index=False, encoding='utf-8')
        print(f"Flight data saved and updated successfully to {output_file}")
        return output_file

    def extract_aircraft_registrations(self, query: str) -> list:
        prompt = (
            f"Extract all aircraft registration numbers from the following user input:\n\n"
            f"{query}\n\n"
            "Registration numbers are usually short codes like ZZ332, ZM409, PK-GJR, etc.\n"
            "Return only the registration numbers as a comma-separated list, with no explanation."
        )

        print(f"query: {query}")
        result = gemini_model.generate_content(prompt)
        response_text = result.text.strip()
        print(f"response_text: {response_text}")

        # Normalize and extract using pattern: two or more letters followed by 2–5 digits or vice versa
        response_text = response_text.replace("[", "").replace("]", "").replace("\"", "").replace("'", "")

        # This catches formats like ZZ332, ZM409, PK-GJR etc.
        registrations = re.findall(r'\b[A-Z]{2,3}-?[A-Z0-9]{2,5}\b', response_text.upper())
        return list(set(registrations))

    def summarize_csv(self, csv_path: str) -> str:
        try:
            df = pd.read_csv(csv_path)
            sample_text = df.head(100).to_csv(index=False)

            prompt = (
                f"Here is a sample of flight data in CSV format:\n\n"
                f"{sample_text}\n\n"
                "Please summarize the data, including flight trends, any unusual patterns, common routes, delays, or anomalies you detect and check for the route each countries flight over them."
            )

            result = gemini_model.generate_content(prompt)
            return result.text

        except Exception as e:
            return f"Failed to summarize CSV: {str(e)}"

class MasterAgent:
    def __init__(self, video_agent: VideoAgent, db_agent: DBAgent):
        self.video_agent = video_agent
        self.db_agent = db_agent
        
        system_prompt = (
            "You are the MasterAgent, responsible for coordinating between specialized sub-agents. "
            "You determine which agents to invoke and in what order to best address the query. "
            "Available agents: VideoAgent (for video analysis), DBAgent (for aircraft registration data). "
            "You can also answer questions directly if no specialized agent is needed."
        )
        self.chat = Chat("MasterAgent", system_prompt=system_prompt)
        
        # Start a chat session with Gemini for more conversational interactions
        self.gemini_chat = gemini_model.start_chat(history=[])
        self.reasoning = []

    def extract_agent_plan(self, planning_response: str) -> list:
        """
        Attempts to parse planning_response as JSON.
        Expected JSON: an array of objects with keys 'agent', 'input', and 'reasoning'.
        If parsing fails, returns a default plan.
        """
        try:
            plan = json.loads(planning_response)
            if isinstance(plan, list):
                return plan
        except json.JSONDecodeError:
            # Try extracting JSON substring
            match = re.search(r'\[.*\]', planning_response, re.DOTALL)
            if match:
                try:
                    plan = json.loads(match.group(0))
                    if isinstance(plan, list):
                        return plan
                except json.JSONDecodeError:
                    pass
        # Fallback default plan.
        return [
            {
                "agent": "VideoAgent",
                "input": "Analyze the video at the provided path for flight information.",
                "reasoning": "The query includes a video file; therefore, video analysis is needed."
            },
            {
                "agent": "DbAgent", 
                "input": "Query the database for relevant information related to the context.",
                "reasoning": "Provide additional context or supplementary information from the database."
            }
        ]
    
    def process(self, prompt: str) -> str:
        """
        The MasterAgent examines the prompt and determines which agents to invoke.
        If the prompt contains a video file path (e.g. ending with '.mp4'), it first calls VideoAgent.
        It prints its reasoning and the responses from each invoked agent.
        """
        outputs = []
        self.reasoning = []
        
        # Store the user query in memory
        self.chat.add_user_message(prompt)
              
        # Step 1: Use Gemini for reasoning and planning with context
        context_summary = ""
        if len(self.chat.memory.interactions) > 1:  # If we have previous interactions
            context_summary = f"\n\nPrevious conversation context: {self.chat.memory.summarize_context()}"
        
        planning_prompt = (
            f"User Query: {prompt}\n{context_summary}\n"
            "Available Assistant Agents:\n"
            "1. VideoAgent: Analyzes video files to extract flight information.\n"
            "2. DBAgent: Extracts aircraft registrations from queries and provides flight data analysis.\n"
            "Determine which agents to invoke and in what order to best address the query. "
            "Do not call the DbAgent right after the VideoAgent, only if the user asked for more data."
            "Return a JSON array where each element is an object with keys 'agent', 'input', and 'reasoning'."
            "If the query can be answered by the MasterAgent directly without needing specialized agents, "
            "return a plan with a single element where 'agent' is 'MasterAgent'."
        )
        
        # Check if this is a follow-up question about previous processing
        is_followup = False
        if len(self.chat.memory.interactions) > 1:
            last_agent_used = self.chat.memory.get_metadata("last_agent_used", None)
            if last_agent_used and "what did you find" in prompt.lower() or "tell me more" in prompt.lower():
                is_followup = True
                self.reasoning.append(f"Master Reasoning: This appears to be a follow-up question about previous {last_agent_used} results.")
                
                if last_agent_used == "VideoAgent":
                    video_response = self.video_agent.process(prompt)
                    outputs.append("VideoAgent Follow-up Response:\n" + video_response)
                    self.chat.memory.add_metadata("last_agent_used", "VideoAgent")
                    self.chat.add_agent_message("\n".join(outputs))
                    return "\n\n".join(outputs)
                
                elif last_agent_used == "DBAgent":
                    db_response = self.db_agent.process(prompt)
                    outputs.append("DBAgent Follow-up Response:\n" + db_response)
                    self.chat.memory.add_metadata("last_agent_used", "DBAgent")
                    self.chat.add_agent_message("\n".join(outputs))
                    return "\n\n".join(outputs)
        
        # If not a follow-up, proceed with regular planning
        if not is_followup:
            planning_response = self.gemini_chat.send_message(planning_prompt)
            
            # Extract agent invocation plan from Gemini's response
            agent_plan = self.extract_agent_plan(planning_response.text)
            
            # Step 2: Execute the plan.
            for step in agent_plan:
                agent_name = step.get("agent")
                reasoning = step.get("reasoning")
                self.reasoning.append(f"Master Reasoning: Invoking {agent_name} because: {reasoning}")
                
                if agent_name.lower() == "videoagent":
                    # For VideoAgent, we use the entire user_query. The VideoAgent will extract and remove the video path.
                    video_response = self.video_agent.process(prompt)
                    outputs.append("VideoAgent Response:\n" + video_response)
                    self.chat.memory.add_metadata("last_agent_used", "VideoAgent")
                
                elif agent_name.lower() == "dbagent":
                    # For DBAgent, we process the query to extract aircraft registrations
                    db_response = self.db_agent.process(prompt)
                    outputs.append("DBAgent Response:\n" + db_response)
                    self.chat.memory.add_metadata("last_agent_used", "DBAgent")
                
                elif agent_name.lower() == "masteragent":
                    # Use the chat interface for more conversational responses
                    master_response = self.gemini_chat.send_message(
                        f"Please respond to the user's query directly: {prompt}"
                    )
                    outputs.append("Master Response:\n" + master_response.text)
                    self.chat.memory.add_metadata("last_agent_used", "MasterAgent")
                else:
                    outputs.append(f"Error: Unknown agent '{agent_name}'")
        
        # Store the agent's response in memory
        full_response = "\n\n".join(outputs)
        self.chat.add_agent_message(full_response)
        
        # Format the final response in HTML
        html_response = "<br>".join(outputs)
        
        return html_response

# --- Interactive Chat Loop (non-streaming) ---
def interactive_chat():
    print("Initializing Agent System...")
    video_agent = VideoAgent()
    master_agent = MasterAgent(video_agent)
    
    print("\n=== Welcome to the Multi-Agent Chat System ===")
    print("Type 'exit' or 'quit' to end the conversation.")
    print("Include a .mp4 video path in your query to analyze a video.\n")
    
    while True:
        user_query = input("You: ")
        if user_query.lower() in ["exit", "quit", "bye"]:
            print("System: Goodbye!")
            break
        
        print("\nProcessing your query...")
        response = master_agent.process(user_query)
        print("\nSystem: " + response)
        print("\n" + "-"*50 + "\n")


video_agent = VideoAgent()
db_agent = DBAgent()
master_agent = MasterAgent(video_agent,db_agent)

# --- Main Execution ---
@app.route("/")
def index():
    return render_template("index.html")  # Ensure this template exists

@app.route("/chat", methods=["POST"])
def chat():
    data = request.json
    user_input = data.get("message", "")
    print("\nProcessing your query...")
    response = master_agent.process(user_input)
    reasoning = "<br>".join(master_agent.reasoning)
    print("\nSystem: " + response)
    print("\n" + "-"*50 + "\n")
    return jsonify({"response": response, "reasoning": reasoning})

if __name__ == "__main__":
    app.run(host='127.0.0.1', port=5000, debug=True)